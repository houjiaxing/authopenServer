<?php

/**
 * Signature 签名
 * by: DerrickZheng
 */
class Signature
{
    /**
     * 计算签名
     * @param $apiName
     * @param $secretKey    接口签名
     * @param $plainText    拼接有效签名串
     * @return array|string
     */
    static function getSignature($apiName,$secretKey,$plainText) {

        if (empty($apiName)) {
            return array("ret"=>-1,"msg"=>"apiName error","signature"=>"");
        }

        $bin = hash_hmac("SHA1", $plainText, $secretKey, true);
        $bin = $bin.$plainText;
//        echo "<br>bin:".$bin;
        $sign = base64_encode($bin);
        return $sign;
    }


}