import org.json.JSONObject;

import util.AES;
import util.HttpRequest;
import util.Signature;
import util.Util;

public class GetDetectinfo {
	public static void main(String[] args) {
		JSONObject obj = new JSONObject();
		
		String token = "{E4100616-FD40-4FE0-A93F-BCB64B6726D9}";
		String appid = "";
		String secretKey = "";
		
		byte[] keyBytes = "".getBytes();
		String plainText = "a="+appid+"&m=getdetectinfo&t="+Util.getCurrentTime()+"&e="+600;

		obj.put("token", token);
		obj.put("appid", appid);
		System.out.println("json--"+obj.toString());
		try {
			String signature = Signature.getSignature(secretKey, plainText);
			
			System.out.println("signature: "+signature);
			String resp = HttpRequest.sendPost("https://iauth-sandbox.wecity.qq.com/new/cgi-bin/getdetectinfo.php", 
									obj.toString(),
									signature, 
							        "application/json"
								);
			
			System.out.println(resp);
			
			obj = new JSONObject(resp);
			String resultData = obj.getString("data");
			System.out.println("Data:"+resultData);
			
			byte[] r = AES.decrypt(resultData.getBytes(), keyBytes);		//AES解密
			System.out.println(new String(r,"UTF-8"));
		
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
