<?php
/**
 * Created by PhpStorm.
 * User: IT8000
 * Date: 2017/8/2
 * Time: 12:40
 */

require_once (dirname(__FILE__) . "/util/util.php");
require_once (dirname(__FILE__) . "/util/AES.php");
require_once (dirname(__FILE__) . "/util/Signature.php");

$url = "https://iauth-sandbox.wecity.qq.com/new/cgi-bin/getdetectinfo.php";
$token = "";
$appid = "";
$apiName = "";
$expired = 600;
$now = time();
$plainText = 'a='.$appid.'&m='.$apiName.'&t='.$now.'&e='.$expired;

echo $plainText."<br>";
$secretKey = "";
$aesKey = "";

$data = json_encode(
    array(
        "token"  => $token ,
        "appid" => $appid
    )
);

echo "data:".$data;
$sign = Util::getAppSign($apiName,$secretKey,$plainText);
echo "<br>signature:".$sign;
$request = array(
    'url' => $url,
    'method' => 'post',
    'timeout' => 100,
    'data' => $data,
    'header' => array(
        'signature:'.$sign,
        'Content-Type:application/json',
    ),
);

$resp = Util::request_post($request);
$jsonArray = json_decode($resp,true);
$data = $jsonArray["data"];
$aesResult = new AES();
echo "<br>解密后结果: ".$aesResult->aes256cbcDecrypt($data,$aesKey);