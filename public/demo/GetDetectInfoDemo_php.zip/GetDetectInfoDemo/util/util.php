<?php
/**
 * 实名核身工具
 * by DerrickZheng
 */

class Util{



    /**
     * 计算签名
     * @param $apiName
     * @param $secretKey    接口签名
     * @param $plainText    拼接有效签名串
     * @return array|string
     */
    static function getAppSign($apiName,$secretKey,$plainText) {

        if (empty($apiName)) {
            return array("ret"=>-1,"msg"=>"apiName error","signature"=>"");
        }

        $bin = hash_hmac("SHA1", $plainText, $secretKey, true);
        $bin = $bin.$plainText;
//        echo "<br>bin:".$bin;
        $sign = base64_encode($bin);
        return $sign;
    }

    /**
     * 发送post请求
     * @param $request
     * @return mixed
     */
    static function request_post($request) {

        if (null != $request['header']){
            $header = $request['header'] ;
        }
        $header[] = 'Method:POST';
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,$request['url']);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, $request['timeout']);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $request['data']);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,false);

        $data = curl_exec($ch);
        echo '<br>';

        echo $data;

        curl_close($ch);

        return $data;

    }
}
