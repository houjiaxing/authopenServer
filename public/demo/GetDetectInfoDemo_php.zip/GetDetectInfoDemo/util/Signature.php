<?php

/**
 * Signature 签名
 * by: DerrickZheng
 */
class Signature
{
    /**
     * 计算签名
     * by:DerrickZheng
     * @param $secretKey    接口签名
     * @param $plainText    拼接有效签名串
     * @return array|string
     */
    static function getSignature($secretKey,$plainText) {
        $bin = hash_hmac("SHA1", $plainText, $secretKey, true);
        $bin = $bin.$plainText;
        $sign = base64_encode($bin);
        return $sign;
    }

    /**
     * 外部接口的签名生成
     *  把appId，appSecret，nonce，timestamp值进行ASCII码从小到大排序（字典序）后sha1
     * @param $sign
     * @return string
     */
    static function getSignatureSort($sign){
        $s = "";
        sort($sign,2);
        foreach ($sign as $value){
            $s.=$value;
        }
//echo "getSignature:".$s."<br>";
        return sha1($s);
    }
}