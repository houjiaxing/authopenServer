<?php
/**
 * auth
 * User: DerrickZheng
 */

require_once(dirname(__FILE__) . '/util/util.php');
require_once (dirname(__FILE__)."/util/Signature.php");


$url = "https://iauth-sandbox.wecity.qq.com/new/cgi-bin/auth.php";

$appid = "";
$redirect = "";
$uid = "";
$type = 0;

$apiName = "auth";
$now = time();
$expired = 600;
//a=4422&m=auth&t=1503545933&e=600
$plainText = 'a='.$appid.'&m='.$apiName.'&t='.$now.'&e='.$expired;
$secretKey = "";
$signature = new Signature();
$sign = $signature->getSignature($secretKey,$plainText);

$data = array(
    "appid"=>$appid,
    "signature"=>$sign,
    "redirect"=>$redirect,
    "uid"=>$uid,
    "type"=>$type
);


$request = array(
    'url' => $url,
    'method' => 'post',
    'timeout' => 100,
    'data' => $data,
    'header' => array(
        'Content-Type: multipart/form-data',
    ),
);

Util::request_post($request);