<?php

/**
 * Signature 签名
 * by: DerrickZheng
 */
class Signature
{
    /**
     * 计算签名
     * by:DerrickZheng
     * @param $secretKey    接口签名
     * @param $plainText    拼接有效签名串
     * @return array|string
     */
    static function getSignature($secretKey,$plainText) {
        $bin = hash_hmac("SHA1", $plainText, $secretKey, true);
        $bin = $bin.$plainText;
        $sign = base64_encode($bin);
        return $sign;
    }
}