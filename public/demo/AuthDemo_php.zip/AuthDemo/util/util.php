<?php
/**
 * 混合部署工具
 * by DerrickZheng
 */

class Util{


    /**
     * 发送post请求
     * @param $request
     * @return mixed
     */
    static function request_post($request) {

        if (null != $request['header']){
            $header = $request['header'] ;
        }
        $header[] = 'Method:POST';
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,$request['url']);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, $request['timeout']);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $request['data']);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,false);

        $data = curl_exec($ch);
        echo '<br>';

        echo $data;

        curl_close($ch);

        return $data;

    }

}
