//
//  CustomUINavigationController.h
//  AuthDemo
//
//  Created by canyouli on 16/9/23.
//  Copyright © 2016年 tencent. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomUINavigationController : UINavigationController

@end
