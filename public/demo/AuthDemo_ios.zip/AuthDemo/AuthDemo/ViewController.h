//
//  ViewController.h
//  AuthDemo
//
//  Created by jardgechen on 16/8/31.
//  Copyright © 2016年 tencent. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


- (IBAction)startAuth:(id)sender;
- (IBAction)startAuthOrcLight:(id)sender;
- (IBAction)startAuthOrcNone:(id)sender;
@property (weak, nonatomic) IBOutlet UITextField *textField;
@property (weak, nonatomic) IBOutlet UITextField *nameTextField;
@property (weak, nonatomic) IBOutlet UITextField *tokenField;
@property (weak, nonatomic) IBOutlet UILabel *resultLabel;
@end

