//
//  TestOcrViewController.m
//  AuthDemo
//
//  Created by canyouli on 16/10/19.
//  Copyright © 2016年 tencent. All rights reserved.
//

#import "TestOcrViewController.h"

@interface TestOcrViewController ()

@end

@implementation TestOcrViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self customNavigationBar];
    [self.view setBackgroundColor:[UIColor whiteColor]];
    // Do any additional setup after loading the view.
    
    CGRect frame = CGRectMake(100.0, 150.0, [UIScreen mainScreen].bounds.size.width - 200, 50);
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    btn.frame = frame;
    //UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(10, 100, screenWidth - 20, 60)];
    [btn setTitle:@"点击进行身份认证" forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(btnPressed:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:btn];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"返回" style:UIBarButtonItemStylePlain target:self action:@selector(backToRoot)];
    
}
- (void)backToRoot {
    [self.navigationController popToRootViewControllerAnimated:YES];
}
-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:NO animated:YES];
}

-(void)btnPressed:(id)sender{
    //这里可以指定nextController，作为点击下一步之后进入的controller
    [_sdk setViewTitle:@"人脸识别"];
    [_sdk startAuth:AuthTypeWithIDCardInfo name:_name idNum:_idNum token:_token parent:self delegate:_delegate signature:_signature nextBtnText:@"下一步" nextController:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// 接入方调用sdk.openAuthPage接口传入此页面后，每当AuthPage打开此页面前会调用此接口，可在此做清理准备操作
- (void)onShowController {
    NSLog(@"onShowController");
}

-(void)customNavigationBar
{
    self.edgesForExtendedLayout = UIRectEdgeNone;
    [self setTitle:@"实名认证"];
    
    UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithTitle:@"返回" style:UIBarButtonItemStylePlain target:self action:@selector(back)];
    self.navigationItem.backBarButtonItem = item;
}

- (void)back
{
    if (self.navigationController.viewControllers.count <= 1) {
        [self dismissViewControllerAnimated:YES completion:nil];
    }else{
        [self.navigationController popViewControllerAnimated:YES];
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
