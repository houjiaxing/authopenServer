//
//  ViewController.m
//  AuthDemo
//
//  Created by jardgechen on 16/8/31.
//  Copyright © 2016年 tencent. All rights reserved.
//
#define ID_KEY @"id_key"
#define NAME_KEY @"name_key"
#define TOKEN_KEY @"token_key"
#import "ViewController.h"
#import <AuthSDK/AuthSDK.h>
#import "TestOcrViewController.h"

@interface ViewController ()<AuthSDKDelegate>
@property (nonatomic) AuthSDK * sdk;
@property (nonatomic) NSString *signature;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setTitle:@"电子身份认证demo"];
    [self customNavigationBar];
    _sdk = [[AuthSDK alloc] initWithServerURL:nil];
    [_sdk setAppId:@"4396" appSecretKey:@"416df0300bd4043fb4d4df5c00b3e280"];
    
    // TODO:获取测试签名,正式签名要从接入方服务器获取
    _signature = [_sdk getDebugSignature];
    
    //将status bar 文本颜色设置为白色
    self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
    NSString *idNum = [[NSUserDefaults standardUserDefaults] objectForKey:ID_KEY];
    if (idNum.length == 0) {
        [_textField setPlaceholder:@"请输入身份证号"];
    } else {
        [_textField setText:idNum];
    }
    NSString *name = [[NSUserDefaults standardUserDefaults] objectForKey:NAME_KEY];
    if (name.length == 0) {
        [_nameTextField setPlaceholder:@"请输入姓名"];
    } else {
        [_nameTextField setText:name];
    }
    NSString *token = [[NSUserDefaults standardUserDefaults] objectForKey:TOKEN_KEY];
    if (token.length == 0) {
        [_tokenField setPlaceholder:@"请输入token"];
    }else {
        [_tokenField setText:token];
    }
    
    UITapGestureRecognizer *tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(keyboardHide:)];
    //设置成NO表示当前控件响应后会传播到其他控件上，默认为YES。
    tapGestureRecognizer.cancelsTouchesInView = NO;
    //将触摸事件添加到当前view
    [self.view addGestureRecognizer:tapGestureRecognizer];
    [self.textField addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
}

//长度检查
-(void)textFieldDidChange:(UITextField *)textField
{
    if (textField == self.textField) {
        if (textField.text.length > 18) {
            textField.text = [textField.text substringToIndex:18];
        }
    }
}


-(void)keyboardHide:(UITapGestureRecognizer*)tap{
    [self.view endEditing:YES];
}

-(void)customNavigationBar
{
    self.edgesForExtendedLayout = UIRectEdgeNone;
    
    UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithTitle:@"返回" style:UIBarButtonItemStylePlain target:self action:@selector(back)];
    self.navigationItem.backBarButtonItem = item;
}

- (void)back
{
    if (self.navigationController.viewControllers.count <= 1) {
        [self dismissViewControllerAnimated:YES completion:nil];
    }else{
        [self.navigationController popViewControllerAnimated:YES];
    }
}

#pragma mark-- AuthSDKDelegate
-(void)onResultBack:(NSDictionary *)result;
{
    NSLog(@"onResultBack ...");
    NSNumber *errCode = [result valueForKey:@"errorcode"];
    NSNumber *intToken = [[result valueForKey:@"data"] valueForKey:@"token"];
    NSString *token = [[result valueForKey:@"data"] valueForKey:@"token"];
    if (!token && intToken && [intToken isKindOfClass:[NSNumber class]]) {
        token = [intToken stringValue];
    }
    if (errCode && [errCode isKindOfClass:[NSNumber class]] && [errCode integerValue] == 0) {
        _tokenField.text = token;
        [self.resultLabel setText:[NSString stringWithFormat:@"验证通过! token:%@", token]];
    }else{
        [self.resultLabel setText:[NSString stringWithFormat:@"验证不通过! token:%@", token]];
    }
    // 通过token获取详细验证信息的接口需要在业务方后台调用，前端不再提供
}

-(void)showResult:(NSString *)text title:(NSString *)title
{
    //for test
//    UIAlertView *alertView =[[UIAlertView alloc]initWithTitle:title message:text delegate:self cancelButtonTitle:@"确定"  otherButtonTitles:nil];
//    [alertView show];
}

- (IBAction)startAuth:(id)sender {
    _signature = [_sdk getDebugSignature];
    [_sdk setViewTitle:@"实名认证"];
    [_sdk startAuth:AuthTypeOcrAll name:nil idNum:nil token :nil parent:self delegate:self signature:_signature];
}
- (IBAction)startAuthOrcBack:(id)sender {
    _signature = [_sdk getDebugSignature];
    [_sdk setViewTitle:@"实名认证"];
    [_sdk startAuth:AuthTypeOcrBack name:nil idNum:nil token :nil parent:self delegate:self signature:_signature];
}

- (IBAction)startAuthOrcLight:(id)sender {
    _signature = [_sdk getDebugSignature];
    [_sdk setViewTitle:@"实名认证"];
    [_sdk startAuth:AuthTypeOcrLight name:nil idNum:nil token :nil parent:self delegate:self signature:_signature];
}

- (IBAction)startAuthOrcNone:(id)sender {
    _signature = [_sdk getDebugSignature];
    [_sdk setViewTitle:@"实名认证"];
    [_sdk startAuth:AuthTypeOcrNone name:nil idNum:nil token :nil parent:self delegate:self signature:_signature];
}
- (IBAction)statAuthWithMsg:(id)sender {
    _signature = [_sdk getDebugSignature];
    [_sdk setViewTitle:@"实名认证"];
    [_sdk startAuth:AuthTypeWithSmsVerify name:nil idNum:nil token :nil parent:self delegate:self signature:_signature];
    
}

- (IBAction)startAuthWithIdInfo:(id)sender {
    if (_nameTextField.text.length == 0) {
        UIAlertView *alertView =[[UIAlertView alloc]initWithTitle:@"温馨提示" message:@"请输入姓名" delegate:self cancelButtonTitle:@"确定"  otherButtonTitles:nil];
        [alertView show];
        return;
    } else if (_textField.text.length == 0 || _nameTextField.text.length == 0) {
        UIAlertView *alertView =[[UIAlertView alloc]initWithTitle:@"温馨提示" message:@"请输入身份证号" delegate:self cancelButtonTitle:@"确定"  otherButtonTitles:nil];
        [alertView show];
        return;
    } else if (![ValidatorTool isValidatedAllIdcard:_textField.text]) {
        UIAlertView *alertView =[[UIAlertView alloc]initWithTitle:@"温馨提示" message:@"身份证号格式错误" delegate:self cancelButtonTitle:@"确定"  otherButtonTitles:nil];
        [alertView show];
        return;
    } else if (![ValidatorTool isValidateName:_nameTextField.text]) {
        UIAlertView *alertView =[[UIAlertView alloc]initWithTitle:@"温馨提示" message:@"姓名格式错误" delegate:self cancelButtonTitle:@"确定"  otherButtonTitles:nil];
        [alertView show];
        return;
    }
    [[NSUserDefaults standardUserDefaults] setObject:_textField.text forKey:ID_KEY];
    [[NSUserDefaults standardUserDefaults] setObject:_nameTextField.text forKey:NAME_KEY];
    _signature = [_sdk getDebugSignature];
    [_sdk setViewTitle:@"实名认证"];
    [_sdk startAuth:AuthTypeWithIDCardInfo name:_nameTextField.text idNum:_textField.text token:nil parent:self delegate:self signature:_signature];
}
- (IBAction)StartAuthWithSecondVerification:(id)sender {
    if (_nameTextField.text.length == 0) {
        UIAlertView *alertView =[[UIAlertView alloc]initWithTitle:@"温馨提示" message:@"请输入姓名" delegate:self cancelButtonTitle:@"确定"  otherButtonTitles:nil];
        [alertView show];
        return;
    } else if (_textField.text.length == 0 || _nameTextField.text.length == 0) {
        UIAlertView *alertView =[[UIAlertView alloc]initWithTitle:@"温馨提示" message:@"请输入身份证号" delegate:self cancelButtonTitle:@"确定"  otherButtonTitles:nil];
        [alertView show];
        return;
    } else if (![ValidatorTool isValidatedAllIdcard:_textField.text]) {
        UIAlertView *alertView =[[UIAlertView alloc]initWithTitle:@"温馨提示" message:@"身份证号格式错误" delegate:self cancelButtonTitle:@"确定"  otherButtonTitles:nil];
        [alertView show];
        return;
    } else if (![ValidatorTool isValidateName:_nameTextField.text]) {
        UIAlertView *alertView =[[UIAlertView alloc]initWithTitle:@"温馨提示" message:@"姓名格式错误" delegate:self cancelButtonTitle:@"确定"  otherButtonTitles:nil];
        [alertView show];
        return;
    }
    [[NSUserDefaults standardUserDefaults] setObject:_textField.text forKey:ID_KEY];
    [[NSUserDefaults standardUserDefaults] setObject:_nameTextField.text forKey:NAME_KEY];
    [[NSUserDefaults standardUserDefaults] setObject:_tokenField.text forKey:TOKEN_KEY];
    _signature = [_sdk getDebugSignature];
    [_sdk setViewTitle:@"实名认证"];
    [_sdk startAuth:AuthSecondVerification name:_nameTextField.text idNum:_textField.text token:_tokenField.text parent:self delegate:self signature:_signature];

}
@end
