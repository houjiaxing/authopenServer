
#ifndef FACEDETECT_EXPORT_H
#define FACEDETECT_EXPORT_H

#ifdef FACEDETECT_STATIC_DEFINE
#  define FACEDETECT_EXPORT
#  define FACEDETECT_NO_EXPORT
#else
#  ifndef FACEDETECT_EXPORT
#    ifdef facedetect_EXPORTS
        /* We are building this library */
#      define FACEDETECT_EXPORT 
#    else
        /* We are using this library */
#      define FACEDETECT_EXPORT 
#    endif
#  endif

#  ifndef FACEDETECT_NO_EXPORT
#    define FACEDETECT_NO_EXPORT 
#  endif
#endif

#ifndef FACEDETECT_DEPRECATED
#  define FACEDETECT_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef FACEDETECT_DEPRECATED_EXPORT
#  define FACEDETECT_DEPRECATED_EXPORT FACEDETECT_EXPORT FACEDETECT_DEPRECATED
#endif

#ifndef FACEDETECT_DEPRECATED_NO_EXPORT
#  define FACEDETECT_DEPRECATED_NO_EXPORT FACEDETECT_NO_EXPORT FACEDETECT_DEPRECATED
#endif

#define DEFINE_NO_DEPRECATED 0
#if DEFINE_NO_DEPRECATED
# define FACEDETECT_NO_DEPRECATED
#endif

#endif
