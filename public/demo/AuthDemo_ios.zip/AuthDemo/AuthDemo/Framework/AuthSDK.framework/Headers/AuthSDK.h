//
//  AuthSDK.h
//  AuthSDK
//
//  Created by jardgechen on 16/8/31.
//  Copyright © 2016年 tencent. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ValidatorTool.h"

typedef void(^HttpRequestSuccessBlock)(id responseObject);
typedef void(^HttpRequestFailBlock)(NSError *error);

typedef NS_ENUM(NSInteger, AuthType) {
        AuthTypeOcrAll = 0,         /**< 有Ocr, 需要用户操作上传身份证正面及反面图片 */
        AuthTypeOcrLight,           /**< 有Ocr, 需要用户操作上传身份证正面图片 */
        AuthTypeOcrBack,            /**< 有Ocr, 需要用户操作上传身份证反面图片 */
        AuthTypeOcrNone,            /**< 没有Ocr, 需要用户手动输入身份信息 */
        AuthTypeWithSmsVerify,      /**< 有OCR, 需要短信验证 */
        AuthTypeWithIDCardInfo,     /**< 仅活体检测, 需要传入姓名和身份证号 */
        AuthSecondVerification      /**< 二次验证 */
};

@protocol AuthSDKDelegate <NSObject>

/**
 回调函数

 @param result 返回的结果
 */
-(void)onResultBack:(NSDictionary *)result;

@end

@interface AuthSDK : NSObject


/**
 初始化服务器URL

 @param serverURL 服务器URL，为nil时 默认为测试服务器地址
 @return 构造函数
 */
-(instancetype)initWithServerURL:(NSString *)serverURL;

-(NSString *)getServerURL;
-(NSString *)getAppId;
-(NSString *)getSDKVersion;

/**
 设置分配给接入方的appid

 @param appId 分配的AppId
 @param appSecretKey 分配的SecretKey
 */
-(void)setAppId:(NSString *)appId appSecretKey:(NSString *)appSecretKey;

/**
 设置页面title

 @param title 页面title
 */
-(void)setViewTitle:(NSString *)title;

/**
 设置验证成功提示语

 @param label 提示语
 */
-(void)setVerifySuccessTipLable:(NSString *)label;

/**
 设置验证失败提示语

 @param label 提示语
 */
-(void)setVerifyFailTipLable:(NSString *)label;

/**
 设置协议文案

 @param protocol 文案
 */
-(void)setProtocol:(NSString *)protocol;

/**
 获取测试签名,正式签名要从接入方服务器获取

 @return 返回签名
 */
-(NSString *)getDebugSignature;

/**
 设置地理位置，为数据上报提供

 @param location 地理位置
 */
-(void)setLocation:(NSString *)location;

/**
 跳转首页（用户协议页）

 @param type 需要跳转的流程
 @param name 身份名字, 不需要时可传入nil
 @param idNum 身份证号, 不需要时可传入nil
 @param token 传入的token, 不需要时可传入nil
 @param vc 父viewController
 @param ocrViewController 如果需要跳转接入方自己的OCR页面，需要传入，否则使用sdk带的OCR页面
 @param signature 签名, 由接入方后台生成的签名
 */
-(void)openAuthPage:(AuthType)type name:(NSString*)name idNum:(NSString*)idNum token:(NSString *)token parent:(UIViewController *)vc ocrViewController:(UIViewController *)ocrViewController signature:(NSString*)signature;

/**
 开始OCR流程

 @param type 需要跳转的流程类型
 @param name 身份证名字, 不需要时可传入nil
 @param idNum 身份号, 不需要时可传入nil
 @param token 需要传入的token, 不需要时可传入nil
 @param vc 父controller
 @param delegate 需要实现回调的Controller
 @param signature 签名, 由接入方后台生成的签名
 */
-(void)startAuth:(AuthType)type name:(NSString*)name idNum:(NSString*)idNum token:(NSString *)token parent:(UIViewController *)vc delegate:(id<AuthSDKDelegate>)delegate signature:(NSString*)signature;

/**
 开始OCR流程,功能同startAuth，可配置两个参数：完成按钮文字、完成按钮跳转到controller

 @param type 需要跳转的流程类型
 @param name 身份证名字, 不需要时可传入nil
 @param idNum 身份号, 不需要时可传入nil
 @param token 需要传入的token, 不需要时可传入nil
 @param vc 父controller
 @param delegate 需要实现回调的Controller
 @param signature 签名, 由接入方后台生成的签名
 @param nextBtnText 完成按钮文字
 @param nextController 完成按钮跳转到controller
 */
-(void)startAuth:(AuthType)type name:(NSString*)name idNum:(NSString*)idNum token:(NSString*) token parent:(UIViewController *)vc delegate:(id<AuthSDKDelegate>)delegate signature:(NSString*)signature nextBtnText:(NSString*)nextBtnText nextController:(UIViewController*)nextController;
@end

