//
//  TestOcrViewController.h
//  AuthDemo
//
//  Created by canyouli on 16/10/19.
//  Copyright © 2016年 tencent. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AuthSDK/AuthSDK.h>

@interface TestOcrViewController : UIViewController

@property (nonatomic) AuthSDK *sdk;
@property (nonatomic) NSString *name;
@property (nonatomic) NSString *idNum;
@property (nonatomic) NSString *signature;
@property (nonatomic, strong) NSString *token;
@property (nonatomic) id delegate;

@end
