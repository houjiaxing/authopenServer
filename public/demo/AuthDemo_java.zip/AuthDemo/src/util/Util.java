package util;

import java.util.Random;

/**
 * 工具
 * @author DerrickZheng
 * 
 */
public class Util {
	
	/**
	 * 生成随机字符串
	 * @param length表示生成字符串的长度
	 * @author DerrickZheng
	 */
	public static String getRandomString(int length) { 
	    String base = "abcdefghijklmnopqrstuvwxyz0123456789";   
	    Random random = new Random();   
	    StringBuffer sb = new StringBuffer();   
	    for (int i = 0; i < length; i++) {   
	        int number = random.nextInt(base.length());   
	        sb.append(base.charAt(number));   
	    }   
	    return sb.toString();   
	}   
	
	
	/**
	 * 生成Unix的时间戳 (不含毫秒)
	 * @author DerrickZheng
	 */
	public static Long getCurrentTime() {
        //毫秒时间转成分钟
        double doubleTime = (Math.floor(System.currentTimeMillis() / 60000L));
        //往下取整 1.9=> 1.0
        long floorValue = new Double(doubleTime).longValue();
        return floorValue * 60;
    }
	
	
}
