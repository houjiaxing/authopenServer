import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.util.LinkedHashMap;
import java.util.Map;

import util.HttpRequest;
import util.Signature;
import util.Util;

public class Auth {
	public static void main(String[] args) {
		String appid = "";
		String redirect = "qw";
		String uid = "1";
		int type = 0; 
		//type=1 时提供只做活体检测时提供
		String id = "";//身份证号
		String name = "";//姓名
		String pic_key = "";
		
		String secretKey = "";
		String plainText = "a="+appid+"&m=auth&t="+Util.getCurrentTime()+"&e="+600;
		
		String random = Util.getRandomString(33);
		
		try {
			String signature = Signature.getSignature(secretKey, plainText);
			System.out.println("signature---"+signature);
			
			Map<String, Object> map = new LinkedHashMap<>();
			map.put("appid", appid);
			map.put("signature", signature);
			map.put("redirect", redirect);
			map.put("uid", uid);
			map.put("type", type);
			String data = HttpRequest.formData(map, random);
			System.out.println("data");
			System.out.println(data);
			System.out.println("header::"+ "Content-Type: multipart/form-data"+"; boundary=----"+random);
			//发送请求
			String resp = HttpRequest.sendPost(
					"https://iauth-sandbox.wecity.qq.com/new/cgi-bin/auth.php", 
					data, 
					null, 
			        "multipart/form-data; boundary=----"+random
			);
			
			System.out.println(resp);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
			
	}
}
